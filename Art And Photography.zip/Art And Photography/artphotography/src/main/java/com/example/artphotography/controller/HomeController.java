package com.example.artphotography.controller;

import com.example.artphotography.model.Artwork;

import com.example.artphotography.service.ArtworkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class HomeController {

    private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

    @Autowired
    private ArtworkService artworkService;

    @GetMapping("/home")
    public String homePage(Model model) {
        logger.info("Loading the homepage and fetching artworks.");
        List<Artwork> artworks = artworkService.getAllArtworks();
        model.addAttribute("artworks", artworks);
        return "home";
    }
}


