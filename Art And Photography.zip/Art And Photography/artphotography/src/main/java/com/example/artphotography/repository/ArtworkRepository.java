package com.example.artphotography.repository;

import com.example.artphotography.model.Artwork;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ArtworkRepository extends JpaRepository<Artwork, Long> {
    // Custom queries can be added if needed
}
