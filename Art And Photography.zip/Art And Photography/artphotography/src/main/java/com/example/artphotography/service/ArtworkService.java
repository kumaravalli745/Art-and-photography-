package com.example.artphotography.service;

import com.example.artphotography.model.Artwork;
import com.example.artphotography.repository.ArtworkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ArtworkService {

    @Autowired
    private ArtworkRepository artworkRepository;

    public List<Artwork> getAllArtworks() {
        return artworkRepository.findAll();
    }

    public Optional<Artwork> getArtworkById(Long id) {
        return artworkRepository.findById(id);
    }

    public Artwork saveArtwork(Artwork artwork) {
        return artworkRepository.save(artwork);  // Saving the artwork to the database
    }

    public void deleteArtwork(Long id) {
        artworkRepository.deleteById(id);
    }

    public Artwork createArtwork(Artwork artwork) {
        return artworkRepository.save(artwork);  // Saving the new artwork to the database
    }

    public Artwork updateArtwork(Long id, Artwork artwork) {
        if (artworkRepository.existsById(id)) {
            artwork.setId(id);  // Ensure the ID is set for the update
            return artworkRepository.save(artwork);  // Save the updated artwork
        }
        return null;  // Return null or throw an exception if the artwork doesn't exist
    }
}
