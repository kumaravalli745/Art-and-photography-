package com.example.artphotography.controller;

import com.example.artphotography.model.Artwork;
import com.example.artphotography.service.ArtworkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")  // CORS for frontend access
@RestController
@RequestMapping("/api")
public class ArtworkRestController {

    @Autowired
    private ArtworkService artworkService;

    @GetMapping("/artworks")
    public List<Artwork> getAllArtworks() {
        return artworkService.getAllArtworks();  // Returns JSON of artworks
    }

    @PostMapping("/artworks")
    public Artwork createArtwork(@RequestBody Artwork artwork) {
        return artworkService.createArtwork(artwork);
    }

    @PutMapping("/artworks/{id}")  // Modified this line
    public Artwork updateArtwork(@PathVariable Long id, @RequestBody Artwork artwork) {
        return artworkService.updateArtwork(id, artwork);
    }

    @DeleteMapping("/artworks/{id}")  // Modified this line
    public String deleteArtwork(@PathVariable Long id) {
        artworkService.deleteArtwork(id);
        return "Artwork with id " + id + " has been deleted.";
    }
}
